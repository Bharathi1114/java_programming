public class StringBench {
    static String plus(int fields) { String s = ""; for (int i = 0; i < fields; i++) s += "Field" + i + ";"; return s; }
    static String sb(int fields) { StringBuilder b = new StringBuilder(); for (int i = 0; i < fields; i++) b.append("Field").append(i).append(';'); return b.toString(); }
    static String sbuf(int fields) { StringBuffer b = new StringBuffer(); for (int i = 0; i < fields; i++) b.append("Field").append(i).append(';'); return b.toString(); }
    static long time(java.util.function.IntFunction<String> f, int tickets, int fields) {
        long best = Long.MAX_VALUE;
        for (int r = 0; r < 5; r++) {
            long t = System.nanoTime();
            for (int i = 0; i < tickets; i++) f.apply(fields);
            best = Math.min(best, System.nanoTime() - t);
        }
        return best / 1_000_000;
    }
    public static void main(String[] a) {
        int[][] loads = {{1, 10}, {10000, 50}, {1000, 500}};
        System.out.printf("%-18s %10s %14s %14s%n", "tickets x fields", "String+ ms", "StringBuilder", "StringBuffer");
        for (int[] w : loads)
            System.out.printf("%-18s %10d %14d %14d%n", w[0] + " x " + w[1],
                time(StringBench::plus, w[0], w[1]), time(StringBench::sb, w[0], w[1]), time(StringBench::sbuf, w[0], w[1]));
    }
}
