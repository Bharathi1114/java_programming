import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
public class Converter extends JFrame {
    private final JTextField amount = new JTextField(10);
    private final JComboBox<String> target = new JComboBox<>(new String[]{"USD", "EUR"});
    private final JLabel result = new JLabel(" ");
    private static double rate(String currency) { return currency.equals("USD") ? 0.012 : 0.011; }
    public Converter() {
        super("Currency Converter");
        setLayout(new FlowLayout());
        JButton convertButton = new JButton("Convert");
        add(new JLabel("INR")); add(amount); add(target); add(convertButton); add(result);
        ActionListener l = e -> convert();          // one lambda for button + Enter key
        convertButton.addActionListener(l);
        amount.addActionListener(l);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
    }
    private void convert() {
        try {
            double inr = Double.parseDouble(amount.getText().trim());
            String cur = (String) target.getSelectedItem();
            result.setText(String.format("%.2f %s", inr * rate(cur), cur));
        } catch (NumberFormatException ex) {
            result.setText("Invalid amount");
        }
    }
    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new Converter().setVisible(true)); }
}
