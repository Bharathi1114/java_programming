public class SeatBooking {
    private final boolean[] booked;
    private int bookingsMade = 0;
    private final boolean safe;
    SeatBooking(int seats, boolean safe) { booked = new boolean[seats]; this.safe = safe; }

    void book(int seat) { if (safe) bookSafe(seat); else bookUnsafe(seat); }

    private void bookUnsafe(int seat) {          // check-then-act race
        if (!booked[seat]) {
            Thread.yield();                       // widen the race window
            booked[seat] = true;
            bookingsMade++;
        }
    }
    // TODO 1: atomic check-then-book
    private synchronized void bookSafe(int seat) {
        if (!booked[seat]) { booked[seat] = true; bookingsMade++; }
    }
    static int run(boolean safe) throws InterruptedException {
        SeatBooking screen = new SeatBooking(10, safe);
        Thread[] users = new Thread[100];
        for (int i = 0; i < users.length; i++) {
            final int seat = i % 10;
            users[i] = new Thread(() -> screen.book(seat));
            users[i].start();
        }
        for (Thread t : users) t.join();
        return screen.bookingsMade;
    }
    public static void main(String[] args) throws InterruptedException {
        System.out.print("Unsynchronized, 10 runs: ");
        for (int i = 0; i < 10; i++) System.out.print(run(false) + " ");
        System.out.print("\nSynchronized,   10 runs: ");
        for (int i = 0; i < 10; i++) System.out.print(run(true) + " ");
        System.out.println("\nSeats sold: " + run(true));
    }
}
