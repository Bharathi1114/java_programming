# CSA09 - Assignment 1 (CO1 - Campus Smart-Parking (OOP))
Name: ________  Register No: ________  Java: 21

Each folder = one task: source (.java) + output.txt.
Compile & run (inside a task folder):  javac *.java && java <MainClass>
Note: the "Complete the Code" TODOs are already filled. Written parts (pseudocode, UML, complexity analysis, tables) must be added in your report.
