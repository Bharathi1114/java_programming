import java.nio.file.*;
public class FindGrowthBench {
    public static void main(String[] a) throws Exception {
        System.out.printf("%-10s %s%n", "records", "avg find (worst case, last pass) ms");
        for (int n : new int[]{1000, 10000, 100000}) {
            Path f = Files.createTempFile("p", ".csv");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < n; i++) sb.append("P").append(i).append(",1923").append(i).append(",Name").append(i).append(",7,3800.0\n");
            Files.writeString(f, sb.toString());
            PassStore s = new PassStore(f);
            long t = System.nanoTime();
            for (int r = 0; r < 20; r++) s.find("P" + (n - 1));
            System.out.printf("%-10d %.3f%n", n, (System.nanoTime() - t) / 20 / 1e6);
            Files.delete(f);
        }
    }
}
