import java.io.*;
import java.nio.file.*;
public class LineCountBench {
    static long unbuffered(Path p) throws IOException {
        long n = 0; try (FileInputStream in = new FileInputStream(p.toFile())) { int b; while ((b = in.read()) != -1) if (b == '\n') n++; } return n;
    }
    static long buffered(Path p) throws IOException {
        long n = 0; try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(p.toFile()), 65536)) { int b; while ((b = in.read()) != -1) if (b == '\n') n++; } return n;
    }
    public static void main(String[] a) throws IOException {
        System.out.printf("%-8s %8s %14s %12s%n", "size MB", "lines", "unbuffered ms", "buffered ms");
        for (int mb : new int[]{1, 10, 50}) {
            Path p = Files.createTempFile("log", ".txt");
            try (BufferedWriter w = Files.newBufferedWriter(p)) {
                long target = mb * 1024L * 1024L, written = 0;
                String line = "2026-01-01,192311001,PRESENT,GATE1\n";
                while (written < target) { w.write(line); written += line.length(); }
            }
            long t1 = System.nanoTime(); long n1 = unbuffered(p); long u = (System.nanoTime() - t1) / 1_000_000;
            long t2 = System.nanoTime(); long n2 = buffered(p);   long b = (System.nanoTime() - t2) / 1_000_000;
            System.out.printf("%-8d %8d %14d %12d%n", mb, n1 == n2 ? n1 : -1, u, b);
            Files.delete(p);
        }
    }
}
